import React from 'react';
import AppBar from '@mui/material/AppBar';
import { styled, alpha } from '@mui/material/styles';
import InputBase from '@mui/material/InputBase';
import Box from '@mui/material/Box';
import Toolbar from '@mui/material/Toolbar';
import SearchIcon from '@mui/icons-material/Search';
import Typography from '@mui/material/Typography';
import Button from '@mui/material/Button';
import ShoppingCartIcon from '@mui/icons-material/ShoppingCart';
import { Link, useNavigate } from 'react-router-dom';


const ResponsiveAppBar = ({ isAuth, logout, role }) => {
  const navigate = useNavigate();

  const Search = styled('div')(({ theme }) => ({
    position: 'relative',
    borderRadius: theme.shape.borderRadius,
    backgroundColor: alpha(theme.palette.common.white, 0.15),
    '&:hover': {
      backgroundColor: alpha(theme.palette.common.white, 0.25),
    },
    marginLeft: '55%',
    width: '100%',
    [theme.breakpoints.up('sm')]: {
      marginLeft: theme.spacing(1),
      width: 'auto',
    },
  }));

  const StyledInputBase = styled(InputBase)(({ theme }) => ({
    color: 'inherit',
    '& .MuiInputBase-input': {
      padding: theme.spacing(1, 1, 1, 0),
      // vertical padding + font size from searchIcon
      paddingLeft: `calc(1em + ${theme.spacing(4)})`,
      transition: theme.transitions.create('width'),
      width: '100%',
      [theme.breakpoints.up('sm')]: {
        width: '12ch',
        '&:focus': {
          width: '20ch',
        },
      },
    },
  }));

  const SearchIconWrapper = styled('div')(({ theme }) => ({
    padding: theme.spacing(0, 2),
    height: '100%',
    position: 'absolute',
    pointerEvents: 'none',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
  }));

  return (
    <AppBar position="static" sx={{ background: '#3f50b0' }}>
      <Toolbar sx={{ display: 'flex', justifyContent: 'space-between' }}>
        <Box
          onClick={() => navigate('/')}
          sx={{ display: 'flex', cursor: 'pointer' }}
        >
          <ShoppingCartIcon />
          <Typography>upGrad E-Shop</Typography>
        </Box>
        <Search>
          <SearchIconWrapper>
            <SearchIcon />
          </SearchIconWrapper>
          <StyledInputBase
            placeholder="Search…"
            inputProps={{ 'aria-label': 'search' }}
          />
        </Search>
        <Box>
          <Link to="/" style={{ color: 'white' }}>
            Home
          </Link>
          {role === 'admin' && (
            <Link
              style={{
                color: 'white',
                marginLeft: '20px',
                marginRight: '20px',
              }}
              to="/add-product"
            >
              Add Product
            </Link>
          )}

          <Button
            variant="contained"
            sx={{ background: '#eb1666' }}
            onClick={() => {
              !isAuth ? navigate('/login') : logout();
            }}
          >
            {!isAuth ? 'Login' : 'Logout'}
          </Button>
        </Box>
      </Toolbar>
    </AppBar>
  );
};
export default ResponsiveAppBar;
