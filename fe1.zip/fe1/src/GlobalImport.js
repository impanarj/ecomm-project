import React, { Fragment, useEffect, useState } from 'react';
import './App.css';

import { Route, Routes } from 'react-router-dom';
import Dashboard from './common/dashboard';
import Login from './common/login';
import SignUp from './common/signup';
import TopNavBar from './components/navbar';
import CardDetail from './common/cardDetail';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import AddProduct from './common/addProduct';
import Productdetails from './common/Productdetails';
import Stepper from './common/Stepper';

function GlobalImport() {
  // console.log(user, auth);
  const [isAuth, setIsAuth] = useState(false);
  const [role, setRole] = useState('customer');
  const navigate = useNavigate();

  // const Layout = useCallback(() => {
  const Layout = () => {
    return (
      <Fragment>
        <TopNavBar />
      </Fragment>
    );
  };

  useEffect(() => {
    // let token = res.data.token;
    let token = localStorage.getItem('token');
    let role = localStorage.getItem('role');
    setIsAuth(!!token);
    setRole(role);
  }, []);

  const logout = () => {
    localStorage.removeItem('token');
    setIsAuth(false);
  };

  // const userDetails = (e) => {

  //   let isAuthorized = "";
  //   if (user !== null && user !== undefined) {
  //     isAuthorized = localStorage.getItem("isAuthorized").toString();
  //     setUser(JSON.parse(user));
  //   }

  //   setAuth(isAuthorized == "true" && user ? true : false);
  // };
  const signIn = async data => {
    try {
      let res = await axios.post(
        'https://upgradbackend.onrender.com/api/v1/auth/login',
        data
      );
      let token = res.data.token;
      let role = res.data.role;
      localStorage.setItem('token', token);
      localStorage.setItem('role', role);
      setIsAuth(!!token);
      setRole(role);
      console.log(res);
      navigate('/');
    } catch (error) {
      console.log(error);
    }
  };
  const signUp = async data => {
    try {
      let res = await axios.post(
        'https://upgradbackend.onrender.com/api/v1/auth/signup',
        data
      );
      let token = res.data.token;
      localStorage.setItem('token', token);
      localStorage.setItem('role', role);
      setIsAuth(!!token);
      setRole(role);
      navigate('/');
    } catch (error) {
      console.log(error);
    }
  };
  return (
    <Fragment>
      <TopNavBar isAuth={isAuth} logout={logout} role={role} />
      <Routes>
        <Route path="/" element={<CardDetail />} />
        <Route
          path="/login"
          element={<Login login={signIn} isAuth={isAuth} />}
        />
        <Route
          path="/signup"
          element={<SignUp signup={signUp} isAuth={isAuth} />}
        />
        <Route path="/" element={<Home/>} />
        <Route path="/add-product" element={<AddProduct />} />
        <Route path="/product" element={<Productdetails />} />
        <Route path="/buy" element={<Stepper />} />
      </Routes>
    </Fragment>
  );
}

export default GlobalImport;
