import React, { useEffect, useState } from 'react';
import Button from '@mui/material/Button';
import Typography from '@material-ui/core/Typography';
import Card from '@mui/material/Card';
import CardActions from '@mui/material/CardActions';
import CardContent from '@mui/material/CardContent';
import CardMedia from '@mui/material/CardMedia';
import CreateRoundedIcon from '@mui/icons-material/CreateRounded';
import DeleteRoundedIcon from '@mui/icons-material/DeleteRounded';
import { Box } from '@material-ui/core';
import axios from 'axios';
import HomeTabs from './homeTabs';
import { useNavigate } from 'react-router-dom';

export default function () {
  const [products, setProducts] = useState([]);
  let token = localStorage.getItem('token');
  const [value, setValue] = React.useState(0);
  const [categories, setCategories] = useState([
    { _id: '243567', name: 'all' },
  ]);
  const navigate = useNavigate();

  const getProducts = async () => {
    try {
      let res = await axios.get(
        `https://upgradbackend.onrender.com/api/v1/product/category/${categories[value].name}`,
        {
          headers: {
            'Content-Type': 'application/json',
            authorization: `Bearer ${token}`,
          },
        }
      );
      setProducts(res.data);
    } catch (error) {
      console.log(error);
    }
  };

  const getCategories = async data => {
    try {
      let res = await axios.get(
        'https://upgradbackend.onrender.com/api/v1/product/categories',
        {
          headers: {
            'Content-Type': 'application/json',
            authorization: `Bearer ${token}`,
          },
        }
      );
      setCategories([{ _id: '243567', name: 'all' }, ...res.data]);
    } catch (error) {
      console.log(error);
    }
  };
  useEffect(() => {
    getCategories();
    getProducts();
  }, []);
  useEffect(() => {
    getProducts();
  }, [value]);

  const handleChange = (event, newValue) => {
    setValue(newValue);
  };

  return (
    <>
      <HomeTabs
        value={value}
        handleChange={handleChange}
        categories={categories}
      />
      <Box
        sx={{
          display: 'flex',
          gap: '50px',
          mt: 5,
          alignItems: 'center',
          justifyContent: 'center',
          flexWrap: 'wrap',
        }}
      >
        {products?.map(item => (
          <Card sx={{ maxWidth: 345 }}>
            <CardMedia sx={{ height: 140 }} image={item.image} />
            <CardContent>
              <Typography gutterBottom variant="h5" component="div">
                <span>{item.name}</span>
                <span style={{ float: 'right' }}> ₹ {item.price}</span>
              </Typography>

              <Typography variant="body2" color="text.secondary">
                {item.desc}
              </Typography>
            </CardContent>
            <CardActions>
              <Button
                size="small"
                variant="contained"
                onClick={() =>
                  navigate('/buy', {
                    state: { item },
                  })
                }
              >
                Buy
              </Button>
              <CreateRoundedIcon style={{ float: 'right' }} />
              <DeleteRoundedIcon style={{ float: 'right' }} />
            </CardActions>
          </Card>
        ))}
      </Box>
    </>
  );
}
