import { Box, Button, Grid, TextField, Typography } from '@mui/material';
import React from 'react';

const ConfirmDetailes = ({ product }) => {
  return (
    <Box>
      <Grid
        container
        rowSpacing={1}
        columnSpacing={{ xs: 1, sm: 2, md: 3 }}
        sx={{
          margin: 'auto',
          display: 'flex',
          justifyContent: 'center',
        }}
      >
        <Grid item xs={5}>
          <Box
            sx={{
              height: '100%',
              display: 'flex',
              flexDirection: 'column',
              justifyContent: 'center',
            }}
          >
            <Typography sx={{ fontSize: '42px' }}>{product.name}</Typography>
            <Typography> Quantity : 1</Typography>

            <Typography
              sx={{ fontSize: '18px', my: 3, color: '#aaa', display: 'flex' }}
            >
              {' '}
              Category :
              <Typography sx={{ fontSize: '18px', color: 'black', ml: 1 }}>
                {product.category.name}
              </Typography>
            </Typography>
            <Typography> {product.desc}</Typography>
            <Typography sx={{ fontSize: '42px', color: 'red' }}>
              ₹{product.price}
            </Typography>
          </Box>
        </Grid>{' '}
        <Grid item xs={5}>
          <Box sx={{ p: 5 }}>
            <Typography sx={{ fontSize: '42px' }}>Address Details</Typography>
            <Typography> {product.desc}</Typography>
          </Box>
        </Grid>
      </Grid>
    </Box>
  );
};

export default ConfirmDetailes;
