import React, { useState, useEffect } from 'react';
import Tabs from '@mui/material/Tabs';
import Tab from '@mui/material/Tab';
import Box from '@mui/material/Box';
import Paper from '@material-ui/core/Paper';
import { makeStyles } from '@material-ui/core/styles';
import axios from 'axios';
export default function ScrollableTabsButtonAuto({
  value,
  handleChange,
  categories,
}) {
  const useTabStyles = makeStyles({
    root: {
      justifyContent: 'center',
    },
    scroller: {
      flexGrow: '0',
    },
  });

  const classes = useTabStyles();
  return (
    <Box
      sx={{
        align: 'center',
        display: 'flex',
        '& .MuiPaper-root': {
          margin: 'auto',
        },
      }}
    >
      <Paper square sx={{ margin: 'auto' }}>
        <Tabs
          value={value}
          indicatorColor="primary"
          textColor="primary"
          onChange={handleChange}
        >
          {categories.map(item => (
            <Tab label={item.name} key={item._id} />
          ))}
        </Tabs>
      </Paper>
    </Box>
  );
}
