import React, { Fragment, useEffect, useState } from 'react';
import Avatar from '@material-ui/core/Avatar';
import Button from '@material-ui/core/Button';
import CssBaseline from '@material-ui/core/CssBaseline';
import TextField from '@material-ui/core/TextField';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import Checkbox from '@material-ui/core/Checkbox';
import Link from '@material-ui/core/Link';
import Grid from '@material-ui/core/Grid';
import Box from '@material-ui/core/Box';
import LockOutlinedIcon from '@material-ui/icons/LockOutlined';
import Typography from '@material-ui/core/Typography';
import { makeStyles } from '@material-ui/core/styles';
import Container from '@material-ui/core/Container';
import { useForm, Controller } from 'react-hook-form';
import axios from 'axios';
import { InputLabel, MenuItem, Select } from '@mui/material';

function MadeWithLove() {
  return (
    <Typography variant="body2" color="textSecondary" align="center">
      {'Built with love by the '}
      <Link color="inherit" href="https://material-ui.com/">
        Material-UI
      </Link>
      {' team.'}
    </Typography>
  );
}

const useStyles = makeStyles(theme => ({
  '@global': {
    body: {
      backgroundColor: theme.palette.common.white,
    },
  },
  paper: {
    marginTop: theme.spacing(8),
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
  },
  avatar: {
    margin: theme.spacing(1),
    backgroundColor: theme.palette.secondary.main,
  },
  form: {
    width: '100%', // Fix IE 11 issue.
    marginTop: theme.spacing(3),
  },
  submit: {
    margin: theme.spacing(3, 0, 2),
  },
}));

export default function AddProduct() {
  const classes = useStyles();
  const { handleSubmit, control } = useForm();
  let token = localStorage.getItem('token');
  const [categories, setCategories] = useState([]);

  const getCategories = async data => {
    try {
      let res = await axios.get(
        'https://upgradbackend.onrender.com/api/v1/product/categories',
        {
          headers: {
            'Content-Type': 'application/json',
            authorization: `Bearer ${token}`,
          },
        }
      );
      setCategories([...res.data]);
    } catch (error) {
      console.log(error);
    }
  };
  useEffect(() => {
    getCategories();
  }, []);

  const addProduct = async data => {
    try {
      let res = await axios.post(
        'https://upgradbackend.onrender.com/api/v1/product',
        data,
        {
          headers: {
            'Content-Type': 'application/json',
            authorization: `Bearer ${token}`,
          },
        }
      );
      console.log(res);
    } catch (error) {
      console.log(error);
    }
  };

  return (
    <Container component="main" maxWidth="xs">
      <CssBaseline />
      <div className={classes.paper}>
        <Typography component="h1" variant="h5">
          Add Product
        </Typography>
        <form
          className={classes.form}
          noValidate
          onSubmit={handleSubmit(data => addProduct(data))}
        >
          <Grid container spacing={2}>
            <Grid item xs={12}>
              <Controller
                control={control}
                name="name"
                render={({ field: { onChange, onBlur, value, ref } }) => (
                  <TextField
                    value={value}
                    variant="outlined"
                    required
                    fullWidth
                    label="Name"
                    autoFocus
                    onChange={onChange}
                    onBlur={onBlur}
                  />
                )}
              />
            </Grid>
            <Grid item xs={12}>
              <Controller
                control={control}
                name="category"
                render={({ field: { onChange, onBlur, value, ref } }) => (
                  <Fragment>
                    <Select
                      id="demo-simple-select"
                      value={value}
                      label="Category"
                      placeholder="Category"
                      onChange={onChange}
                      onBlur={onBlur}
                      sx={{ width: '100%' }}
                    >
                      {categories.map(item => (
                        <MenuItem value={item.name}>{item.name}</MenuItem>
                      ))}
                    </Select>
                  </Fragment>
                )}
              />
            </Grid>
            <Grid item xs={12}>
              <Controller
                control={control}
                name="manufacturer"
                render={({ field: { onChange, onBlur, value, ref } }) => (
                  <TextField
                    value={value}
                    variant="outlined"
                    required
                    fullWidth
                    label="Manufacturer"
                    onChange={onChange}
                    onBlur={onBlur}
                  />
                )}
              />
            </Grid>
            <Grid item xs={12}>
              <Controller
                control={control}
                name="stock"
                render={({ field: { onChange, onBlur, value, ref } }) => (
                  <TextField
                    value={value}
                    variant="outlined"
                    required
                    fullWidth
                    label="Available Stock"
                    onChange={onChange}
                    onBlur={onBlur}
                  />
                )}
              />
            </Grid>
            <Grid item xs={12}>
              <Controller
                control={control}
                name="price"
                render={({ field: { onChange, onBlur, value, ref } }) => (
                  <TextField
                    value={value}
                    variant="outlined"
                    required
                    fullWidth
                    label="Price"
                    onChange={onChange}
                    onBlur={onBlur}
                  />
                )}
              />
            </Grid>
            <Grid item xs={12}>
              <Controller
                control={control}
                name="image"
                render={({ field: { onChange, onBlur, value, ref } }) => (
                  <TextField
                    value={value}
                    variant="outlined"
                    required
                    fullWidth
                    label="Image URL"
                    onChange={onChange}
                    onBlur={onBlur}
                  />
                )}
              />
            </Grid>
            <Grid item xs={12}>
              <Controller
                control={control}
                name="desc"
                render={({ field: { onChange, onBlur, value, ref } }) => (
                  <TextField
                    value={value}
                    variant="outlined"
                    required
                    fullWidth
                    label="Product Description"
                    onChange={onChange}
                    onBlur={onBlur}
                  />
                )}
              />
            </Grid>
          </Grid>
          <Box>
            {' '}
            <Button
              type="submit"
              fullWidth
              variant="contained"
              color="primary"
              display="flex"
              className={classes.submit}
              alignItems="flex-start"
              justifyContent="flex-start"
            >
              Save Product
            </Button>
          </Box>
        </form>
      </div>
      <Box mt={5}>
        <MadeWithLove />
      </Box>
    </Container>
  );
}
