import React from 'react';
import GlobalImport from './GlobalImport';
import ResponsiveAppBar from './components/navbar';

import CardDetails from './common/cardDetail';
import HomeTabs from './common/homeTabs';
import AddAddress from './common/addAddress';
import AddProduct from './common/addProduct';
import ModifyProduct from './common/modifyProduct';
import { BrowserRouter } from 'react-router-dom';

function App() {
  return (
    <BrowserRouter>
      <div>
        <GlobalImport />
        {/* <ResponsiveAppBar />*/}
        {/* <SignIn /> */}
        {/* <SignUp /> */}
        {/*  <HomeTabs />*/}
        {/* <CardDetails /> */}
        {/* <AddAddress /> */}
        {/* <AddProduct />*/}
      </div>
    </BrowserRouter>
  );
}

export default App;
